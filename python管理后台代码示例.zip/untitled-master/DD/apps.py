from django.apps import AppConfig


class DdConfig(AppConfig):
    name = 'DD'
